對於 section `2.Experiment setups`和`3.Result of testing`皆由 base code 的 `main.py`來陳述。

至於 section `4.Discussion`和`5.Extra`則會另外寫成`diff_*.py`開頭的 codes。
